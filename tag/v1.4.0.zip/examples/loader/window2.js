Nex.setLoaderShims('Nex/window/jquery.nexWindow.js',['Nex/showat/jquery.nexShowAt.js','Nex/jquery.nexHtml.js']);
Nex.require([
	'Nex/window/jquery.nexWindow.js',
	'Nex/jquery.nexAjax.js'
],function(  ){
	//console.log( this );
	var window2 = Nex.define('Nex.Window2','window');
	//Nex.exports(window2);
	window2.setOptions(function(opt,win){
		return {
			title : 'window2',
			closeable : true,
			width : 400,
			height : 400,
			html : 'ddddddddddd'	
		};
	});
});