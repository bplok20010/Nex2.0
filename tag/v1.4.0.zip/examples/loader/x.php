<?php
	sleep(2);
?>
console.log('a');