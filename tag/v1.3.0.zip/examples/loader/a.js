console.log('a');
Nex.requireAlias('Nex.Button','{{_nex_}}/button/jquery.nexButton.js');
Nex.require(['Nex.Button','f','e','g'],function(){
	console.log('23');
});