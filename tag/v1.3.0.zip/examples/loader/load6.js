console.log(6)
Nex.require( ['load4'],function(){ 
				 exports('6');
} );
