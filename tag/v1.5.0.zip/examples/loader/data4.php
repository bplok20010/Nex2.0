<?php
sleep(2);
?>
exports('php-4')
console.log( 'php-4' )				